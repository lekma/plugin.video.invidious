# plugin.video.invidious
Invidious Addon for Kodi.

Install the Invidious [repository](https://github.com/DavidHenryThoreau/plugin.video.invidious/blob/master/repo/repository.invidious/repository.invidious-0.0.1.zip?raw=true) on Kodi and then install Invidious addon and stay up-to-date.

[Invidious instances](https://instances.invidio.us/?sort_by=health)
